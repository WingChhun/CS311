
//INTRUCTION
//Complete the partition routine in quicksort.cpp(given) so that the defined array will be sorted in correct order
//except for the trace messages

//=========================================================
//HW#: HW4 Quicksort
//Your name: James Chhun
//Complier:  MS Visual Studio Ultiamte 2012
//File type: client program
//===========================================================


// quicksort.cpp : Defines the entry point for the console application.
//


#include<iostream>

using namespace std;


//Swap Contents of a and b using pointers
void swap(int* a, int* b)
{
  int t = *a;
  *a = *b;
  *b = t;
}

//Partition array using contents of the array at index "high" as the pivot
int partition (int arr[], int low, int high)
{
  //Variables
  int pivot = arr[high]; 
  int pIndex = low; //set partition index as start


  for(int i = low; i < high; i++) //loop through the array
    {
      if(arr[i] <= pivot) 
	{
	  swap(arr[i], arr[pIndex]); //swap when element less than pivot
	  pIndex++; 
	}
    }

  //Call Swap Function, swap contents of arr'pindex with arrhigh
  swap(arr[pIndex], arr[high]); 

  return pIndex; //return pIndex to quickSort routine to be used as new pivot
}

//QuickSort
//Use Recursion to sort the array using quicksort algorithm
void quickSort(int arr[], int low, int high)
{

  if (low <= high)
    {
      int pi = partition(arr, low, high); //return pivot from partition functino call

      //Recursively Call QuickSort 
      quickSort(arr, low, pi - 1); //sort the lower half of the partition
      quickSort(arr, pi + 1, high); //sort the higher half of the partition
    }
}

//PrintArray
//Print contents of array to console
void printArray(int arr[], int size)
{
  int i;
  for (i=0; i < size; i++)
    cout << arr[i] << " ";
  cout << endl;
}

//MAIN
int main()
{
  int arr[] = {10, 7, 8, 9, 1, 5};
  int n = sizeof(arr)/sizeof(arr[0]);
  quickSort(arr, 0, n-1);
  cout << "Sorted array: " << endl;
  printArray(arr, n);
  // system("pause");
  return 0;
}
