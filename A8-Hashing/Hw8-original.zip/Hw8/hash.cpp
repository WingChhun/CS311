/*
#include "hash.h"
HashMap::HashMap(int size) {}
HashMap::~HashMap() {}
...
*/
